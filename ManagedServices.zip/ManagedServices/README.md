# Introduction 
This is a Managed Service 

# Managed Azure Service deployment




## Update management


### Example configuration file
```
[
    {
        "name": "group-prod-win-1",
        "tagValue": "group-prod-1",
        "scheduleTime": "02:00",
        "description": "Update management group Production Windows 1",
        "operatingSystem": "Windows",
        "windowDurationHours": 2,
        "dayOfWeek": "Tuesday",
        "dayOfWeekOccurence": "Third"
    },
    {
        "name": "group-prod-win-2",
        "tagValue": "group-prod-2",
        "scheduleTime": "02:00",
        "description": "Update management group Production Windows 2",
        "operatingSystem": "Windows",
        "windowDurationHours": 2,
        "dayOfWeek": "Thursday",
        "dayOfWeekOccurence": "Third"
    },
    {
        "name": "group-prod-lin-1",
        "tagValue": "group-prod-1",
        "scheduleTime": "02:00",
        "description": "Update management group Production Linux 1",
        "operatingSystem": "Linux",
        "windowDurationHours": 2,
        "dayOfWeek": "Tuesday",
        "dayOfWeekOccurence": "Third"
    },
    {
        "name": "group-prod-lin-2",
        "tagValue": "group-prod-2",
        "scheduleTime": "02:00",
        "description": "Update management group Production Linux 2",
        "operatingSystem": "Linux",
        "windowDurationHours": 2,
        "dayOfWeek": "Thursday",
        "dayOfWeekOccurence": "Third"
    },
    {
        "name": "group-nonprod-win-1",
        "tagValue": "group-nonprod-1",
        "scheduleTime": "02:00",
        "description": "Update management group Non-Production Windows 1",
        "operatingSystem": "Windows",
        "windowDurationHours": 2,
        "dayOfWeek": "Thursday",
        "dayOfWeekOccurence": "Second"
    },
    {
        "name": "group-nonprod-win-2",
        "tagValue": "group-nonprod-2",
        "scheduleTime": "02:00",
        "description": "Update management group Non-Production Windows 2",
        "operatingSystem": "Windows",
        "windowDurationHours": 2,
        "dayOfWeek": "Friday",
        "dayOfWeekOccurence": "Second"
    },
    {
        "name": "group-nonprod-lin-1",
        "tagValue": "group-nonprod-1",
        "scheduleTime": "02:00",
        "description": "Update management group Non-Production Linux 1",
        "operatingSystem": "Linux",
        "windowDurationHours": 2,
        "dayOfWeek": "Thursday",
        "dayOfWeekOccurence": "Second"
    },
    {
        "name": "group-nonprod-lin-2",
        "tagValue": "group-nonprod-2",
        "scheduleTime": "02:00",
        "description": "Update management group Non-Production Linux 2",
        "operatingSystem": "Linux",
        "windowDurationHours": 2,
        "dayOfWeek": "Friday",
        "dayOfWeekOccurence": "Second"
    }
]
```


# Build and Test
TODO: Describe and show how to build your code and run the tests. 

# Contribute
TODO: Explain how other users and developers can contribute to make your code better. 



