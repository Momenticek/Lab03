[CmdletBinding()]
Param(
    [Parameter(Mandatory = $true)]
    [string]
    $BackupVaultRGName,
    [Parameter(Mandatory = $true)]
    [string]
    $BackupVaultName,
    [Parameter(Mandatory = $true)]
    [string]
    $BackupPolicyName,
    [Parameter(Mandatory = $true)]
    [string]
    $LogAnalyticsWorkspaceName,
    [Parameter(Mandatory = $true)]
    [string]
    $Location,
    [Parameter(Mandatory = $false)]
    [string]
    $DiagSettingsName = "tem-ms-diagsettings"
)

################# Assign Recovery Services Vault diagnostic settings
$policyDef = Get-AzPolicyDefinition -Name "c717fb0c-d118-4c43-ab3d-ece30ac81fb3"
$subscriptionId = (Get-AzContext).Subscription.Id

$workspace = Get-AzResource -ResourceType Microsoft.OperationalInsights/workspaces -Name $LogAnalyticsWorkspaceName
$workspaceId = $workspace.ResourceId
$policyParams = @{
    "logAnalytics" = $workspaceId
    "profileName" = $diagSettingsName
}
$policyAssignmentName = 'TietoEVRYMSEnableRSVDiagAssignment'
$assignment = New-AzPolicyAssignment -Name $policyAssignmentName -DisplayName 'TietoEVRY Managed Service Enable Recovery Services Vault Diagnostic Settings' -Scope "/subscriptions/$SubscriptionId" -PolicyDefinition $policyDef -Location $location -PolicyParameterObject $policyParams -AssignIdentity

Start-Sleep 20

# Use the $policyDef to get to the roleDefinitionIds array
#$roleDefinitionIds = $policyDef.Properties.policyRule.then.details.roleDefinitionIds
$roleDefId = "b24988ac-6180-42a0-ab88-20f7382dd24c"

New-AzDeployment -Location $Location -TemplateFile "$env:BUILD_SOURCESDIRECTORY\Templates\Policy\rbac-assignment-lighthouse.json" -policyAssignmentName $policyAssignmentName -rbacRoleId $roleDefId

Start-Sleep 15

# Create a remediation for a specific assignment
Start-AzPolicyRemediation -Name 'tem-backup-rsvdiag-remediation' -PolicyAssignmentId $assignment.PolicyAssignmentId -ResourceDiscoveryMode ReEvaluateCompliance



####################
# Assign Backup policy

$policyDef = Get-AzPolicyDefinition -Name "TietoEVRYMSBackupPolicy"
$subscriptionId = (Get-AzContext).Subscription.Id

$policyParams = @{
    "BackupVaultRGName"=$BackupVaultRGName
    "BackupVaultName"=$BackupVaultName
    "BackupPolicyName"=$BackupPolicyName
}
$policyAssignmentName = 'TietoEVRYMSBackupPolicyAssignment'
$assignment = New-AzPolicyAssignment -Name $policyAssignmentName -DisplayName 'TietoEVRY Managed Service Backup Policy' -Scope "/subscriptions/$SubscriptionId" -PolicyDefinition $policyDef -Location $location -PolicyParameterObject $policyParams -AssignIdentity

Start-Sleep 20

# Use the $policyDef to get to the roleDefinitionIds array
#$roleDefinitionIds = $policyDef.Properties.policyRule.then.details.roleDefinitionIds
$roleDefId = "b24988ac-6180-42a0-ab88-20f7382dd24c"

New-AzDeployment -Location $Location -TemplateFile "$env:BUILD_SOURCESDIRECTORY\Templates\Policy\rbac-assignment-lighthouse.json" -policyAssignmentName $policyAssignmentName -rbacRoleId $roleDefId

Start-Sleep 15

# Create a remediation for a specific assignment
Start-AzPolicyRemediation -Name 'tem-backup-policy-remediation' -PolicyAssignmentId $assignment.PolicyAssignmentId -ResourceDiscoveryMode ReEvaluateCompliance