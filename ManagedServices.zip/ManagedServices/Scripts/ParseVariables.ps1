[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $jsonFile
)

function GetArray([string]$varibleName, [string] $variblePrefix, $vars)
{
    $arrayHash = @{};
    $array = @{};
    $upperCasePrefix = $variblePrefix.ToUpperInvariant();
    $indexPrevious = "";

    foreach ($var in $vars)
    {
        if ($var.Key.StartsWith($upperCasePrefix))
        {
            $name = $var.Key.SubString($var.Key.IndexOf("_") + 1);
            $index = $name.SubString(0, $name.IndexOf("_"));
            $arrayVarName = $name.SubString($name.IndexOf("_") + 1);

            if ($index -eq $indexPrevious)
            {
                $arrayHash.Add($arrayVarName.ToLowerInvariant(), $var.Value);
            }
            else 
            {
                if ($arrayHash.Count -gt 0)
                {
                    $array.Add($indexPrevious, $arrayHash);
                    $arrayHash = @{};
                }
                $arrayHash.Add($arrayVarName.ToLowerInvariant(), $var.Value);
            }
            $indexPrevious = $index;
        }
    }
    if ($array.Count -gt 0)
    {
        $array.Add($indexPrevious, $arrayHash);
    }

    $valueHash = @{};
    $valueHash.Add("value", $array.Values)
    return $valueHash;
}
function GetObject([string]$varibleName, [string] $variblePrefix, $vars)
{
    $variableHash = @{};
    $upperCasePrefix = $variblePrefix.ToUpperInvariant();

    foreach ($var in $vars)
    {
        if ($var.Key.StartsWith($upperCasePrefix))
        {
            $name = $var.Key.SubString($var.Key.IndexOf("_") + 1);
            $variableHash.Add($name.ToLowerInvariant(), $var.Value);
        }
    }

    $valueHash = @{};
    $valueHash.Add("value", $variableHash)
    return $valueHash;
}

Write-Host "Reading Env Varibles"
$vars = Get-Childitem -Path Env:* | Sort-Object Name

$paramFile = @{};
$paramFile.Add("`$schema", "https://schema.management.azure.com/schemas/2015-01-01/deploymentParameters.json#");
$paramFile.Add("contentVersion", "1.0.0.0");
$paramHash = @{}; 

$variableName = "settings"
Write-Host "Processing $variableName"
$variableHash = GetObject $variableName "settings" $vars;
$paramHash.Add($variableName, $variableHash);

$variableName = "resourcegroups"
Write-Host "Processing $variableName"
$variableHash = GetObject $variableName "resourcegroups" $vars;
$paramHash.Add($variableName, $variableHash);

# $variableName = "network"
# Write-Host "Processing $variableName"
# $variableArray = GetArray $variableName "network" $vars;
# $hash.Add($variableName, $variableArray);

Write-Host "Writing JSON to $jsonFile"
$paramFile.Add("parameters", $paramHash);
ConvertTo-Json $paramFile -Depth 5 | Out-File -FilePath $jsonFile -Encoding "UTF-8"
