[CmdletBinding()]
Param(
    [Parameter(Mandatory = $true)]
    [string]
    $TagName,
    [Parameter(Mandatory = $true)]
    [string]
    $TagValue,
    [Parameter(Mandatory = $true)]
    [string]
    $Location
)

$policyDef = Get-AzPolicyDefinition -Name "TietoEVRYMSUpdMgmtPolicy"
$subscriptionId = (Get-AzContext).Subscription.Id

$policyParams = @{
    "tagName"=$TagName
    "tagValue"=$TagValue
}

$policyAssignmentName = 'TietoEVRYMSUpdMgmtPolicyAssignment'
$assignment = New-AzPolicyAssignment -Name $policyAssignmentName -DisplayName 'TietoEVRY Managed Service Update Management Policy' -Scope "/subscriptions/$SubscriptionId" -PolicyDefinition $policyDef -Location $location -PolicyParameterObject $policyParams -AssignIdentity

Start-Sleep 20

# Use the $policyDef to get to the roleDefinitionIds array
#$roleDefinitionIds = $policyDef.Properties.policyRule.then.details.roleDefinitionIds
$roleDefId = "b24988ac-6180-42a0-ab88-20f7382dd24c"

New-AzDeployment -Location $Location -TemplateFile "$env:BUILD_SOURCESDIRECTORY\Templates\Policy\rbac-assignment-lighthouse.json" -policyAssignmentName $policyAssignmentName -rbacRoleId $roleDefId

Start-Sleep 15

# Create a remediation for a specific assignment
Start-AzPolicyRemediation -Name 'tem-updmgmt-tags-remediation' -PolicyAssignmentId $assignment.PolicyAssignmentId -ResourceDiscoveryMode ReEvaluateCompliance