[CmdletBinding()]
param (	
    [Parameter()]
    [string]$SubscriptionId,
    [Parameter()]
    [string]$MonitoringResourceGroup,
    [Parameter()]
    [string]$AutomationAccountName,
    [Parameter()]
    [string]$TimeZone,
    [Parameter()]
    [string]$GroupTagName
)


Import-Module Az.Automation


Function CalculateScheduleTime {
    Param (
        [string]$scheduleTime = "00:00"
    )
    
    $currentDateTime = Get-Date
    $currentDate = Get-Date -Format yyyy-MM-dd
    $scheduleDateTime = Get-Date($currentDate + " " + $scheduleTime)
    if ($scheduleDateTime -lt $currentDateTime.AddMinutes(10)) {
        $scheduleDateTime = $scheduleDateTime.AddDays(1)
    }
    $scheduleDateTime
}

$monthInterval = 1

$scheduleConfigJson = Get-Content -Raw -Path "$env:BUILD_SOURCESDIRECTORY\Scripts\Update Management\config\default-config.json"
$scheduleConfig = ConvertFrom-Json $scheduleConfigJson

foreach ($schedule in $scheduleConfig) {
    $scheduleName = $schedule.Name
    $scheduleDescription = $schedule.Description
    $groupTagValue = $schedule.TagValue
    $operatingSystem = $schedule.OperatingSystem
    $scheduleTime = $schedule.scheduleTime
    $windowDurationHours = $schedule.WindowDurationHours
    $dayOfWeek = $schedule.DayOfWeek
    $dayOfWeekOccurence = $schedule.DayOfWeekOccurence

    $startTime = CalculateScheduleTime -scheduleTime $scheduleTime
    $schedule = New-AzAutomationSchedule -ResourceGroupName $MonitoringResourceGroup `
                                        -AutomationAccountName $AutomationAccountName  `
                                        -StartTime $startTime `
                                        -Name $scheduleName `
                                        -Description $scheduleDescription `
                                        -DayOfWeek $dayOfWeek `
                                        -DayOfWeekOccurrence $dayOfWeekOccurence `
                                        -MonthInterval $monthInterval `
                                        -TimeZone $TimeZone `
                                        -ForUpdateConfiguration

    # Using AzAutomationUpdateManagementAzureQuery to create dynamic groups
    $queryScope = @("/subscriptions/$SubscriptionId")

    $umGroupTag = @{"$groupTagName"= @("$groupTagValue")}

    $DGQuery = New-AzAutomationUpdateManagementAzureQuery -ResourceGroupName $MonitoringResourceGroup `
                                        -AutomationAccountName $AutomationAccountName `
                                        -Scope $queryScope `
                                        -Tag $umGroupTag

    $AzureQueries = @($DGQuery)

    if ($operatingSystem -eq "Windows") {
        New-AzAutomationSoftwareUpdateConfiguration -ResourceGroupName $MonitoringResourceGroup `
                                                    -AutomationAccountName $AutomationAccountName `
                                                    -Schedule $schedule `
                                                    -Windows `
                                                    -Duration (New-TimeSpan -Hours $windowDurationHours) `
                                                    -AzureQuery $AzureQueries `
                                                    -IncludedUpdateClassification Security,Critical
    } elseif ($operatingSystem -eq "Linux") {
        New-AzAutomationSoftwareUpdateConfiguration -ResourceGroupName $MonitoringResourceGroup `
                                                    -AutomationAccountName $AutomationAccountName `
                                                    -Schedule $schedule `
                                                    -Linux `
                                                    -Duration (New-TimeSpan -Hours $windowDurationHours) `
                                                    -AzureQuery $AzureQueries `
                                                    -IncludedPackageClassification Security,Critical

    }

}