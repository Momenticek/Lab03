function CreateVariableGroup {
    param (
        [string]$variableGroupName,
        [string[]]$variables,
        [string]$organizationUrl,
        [string]$projectName
    )
    az pipelines variable-group create --name $variableGroupName --variables $variables --organization $organizationUrl --project $projectName --authorize true | ConvertFrom-Json
}

$orgName = "TietoEVRYAzureDevOps"
$projectName = "TietoEVRYPublicCloudCoreServices"

$organizationUrl = "https://dev.azure.com/$orgName/"


$variablesTest = @(
    'admin.azureConnection=TietoEVRY Azure DevOps II - Lighthouse',
    'admin.subscriptionId=e5f3913a-4b59-46d9-bd7d-8466273a0edd'
    'backup.policyName=daily-vm-backup-01'
    'backup.resourceGroup=tem-backup-rg'
    'backup.retentionDays=90'
    'backup.scheduleTime=[\"01:00:00Z\"]'
    'backup.scheduleTimeZone=UTC'
    'backup.storageType=GeoRedundant'
    'backup.vaultName=tem-backup-rsv-9a0fc'
    'monitoring.automationAccountName=tem-monitoring-automation'
    'monitoring.enabledSolutions=[\"all\"]'
    'monitoring.resourceGroup=tem-monitoring-rg'
    'monitoring.workspaceName=tem-monitoring-workspace-9a0fc'
    'settings.location=WestEurope'
    'updmgmt.configFileName=default-config.json'
    'updmgmt.defaultGroupTagValue=group-prod-1'
    'updmgmt.groupTagName=tem-updmgmt-group'
    'updmgmt.scheduleTimeZone=UTC'
)

CreateVariableGroup -variableGroupName 'TestManagedServices2100' -variables $variablesTest -organizationUrl $organizationUrl -projectName $projectName