$connectionNamePrefix = "TietoEVRYAzureDevOps-IvarManagedService"
$roleName = "Resource Policy Contributor"
$subscriptionId = "a4252914-5bc9-4870-b365-eed4e1a37dfd"

$roles = Get-AzRoleAssignment -Scope /subscriptions/$subscriptionId | where {$_.DisplayName -like "$($connectionNamePrefix)*"}
$objectId = $roles[0].ObjectId

New-AzRoleAssignment -RoleDefinitionName $roleName -ObjectId $objectId -Scope /subscriptions/$subscriptionId