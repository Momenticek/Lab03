[CmdletBinding()]
Param(
    [Parameter(Mandatory = $true)]
    [string]
    $Location
)


# Deploy Network Watcher policy
$policyDef = Get-AzPolicyDefinition -Name "a9b99dd8-06c5-4317-8629-9d86a3c6e7d9"
$subscriptionId = (Get-AzContext).Subscription.Id

$policyAssignmentName = 'TietoEVRYMSNetworkWatcherAssignment'
$assignment = New-AzPolicyAssignment -Name $policyAssignmentName -DisplayName 'TietoEVRY Managed Service Network Watcher Policy' -Scope "/subscriptions/$SubscriptionId" -PolicyDefinition $policyDef -Location $location -AssignIdentity

Start-Sleep 20

# Use the $policyDef to get to the roleDefinitionIds array
#$roleDefinitionIds = $policyDef.Properties.policyRule.then.details.roleDefinitionIds
$roleDefId = "b24988ac-6180-42a0-ab88-20f7382dd24c"

New-AzDeployment -Location $Location -TemplateFile "$env:BUILD_SOURCESDIRECTORY\Templates\Policy\rbac-assignment-lighthouse.json" -policyAssignmentName $policyAssignmentName -rbacRoleId $roleDefId

Start-Sleep 15

# Create a remediation for a specific assignment
Start-AzPolicyRemediation -Name 'tem-policy-networkwatcher-remediation' -PolicyAssignmentId $assignment.PolicyAssignmentId -ResourceDiscoveryMode ReEvaluateCompliance


# Deploy IaaS Antimalware policy
$policyDef = Get-AzPolicyDefinition -Name "2835b622-407b-4114-9198-6f7064cbe0dc"
$subscriptionId = (Get-AzContext).Subscription.Id

$policyAssignmentName = 'TietoEVRYMSIaaSAntimalwareAssignment'
$assignment = New-AzPolicyAssignment -Name $policyAssignmentName -DisplayName 'TietoEVRY Managed Service IaaS Antimalware Policy' -Scope "/subscriptions/$SubscriptionId" -PolicyDefinition $policyDef -Location $location -AssignIdentity

Start-Sleep 20

# Use the $policyDef to get to the roleDefinitionIds array
#$roleDefinitionIds = $policyDef.Properties.policyRule.then.details.roleDefinitionIds
$roleDefId = "b24988ac-6180-42a0-ab88-20f7382dd24c"

New-AzDeployment -Location $Location -TemplateFile "$env:BUILD_SOURCESDIRECTORY\Templates\Policy\rbac-assignment-lighthouse.json" -policyAssignmentName $policyAssignmentName -rbacRoleId $roleDefId

Start-Sleep 15

# Create a remediation for a specific assignment
Start-AzPolicyRemediation -Name 'tem-policy-iaasantimalware-remediation' -PolicyAssignmentId $assignment.PolicyAssignmentId -ResourceDiscoveryMode ReEvaluateCompliance