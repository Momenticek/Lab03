[CmdletBinding()]
Param(
    [Parameter(Mandatory = $true)]
    [string]
    $LogAnalyticsWorkspaceName,
    [Parameter(Mandatory = $true)]
    [string]
    $Location
)

# Assign VM monitoring policy initiative
$policySetDef = Get-AzPolicySetDefinition -Name "55f3eceb-5573-4f18-9695-226972c6d74a"
$subscriptionId = (Get-AzContext).Subscription.Id

$workspace = Get-AzResource -ResourceType Microsoft.OperationalInsights/workspaces -Name $LogAnalyticsWorkspaceName
$workspaceId = $workspace.ResourceId
$policyParams = @{
    "logAnalytics_1" = $workspaceId
}
$policyAssignmentName = 'TietoEVRYMSAzureMonitorVMsAssignment'
$assignment = New-AzPolicyAssignment -Name $policyAssignmentName -DisplayName 'TietoEVRY Managed Service Azure Monitor for VMs Policy' -Scope "/subscriptions/$SubscriptionId" -PolicySetDefinition $policySetDef -Location $location -PolicyParameterObject $policyParams -AssignIdentity

Start-Sleep 20

# Use the $policyDef to get to the roleDefinitionIds array
#$roleDefinitionIds = $policyDef.Properties.policyRule.then.details.roleDefinitionIds
$roleDefId = "b24988ac-6180-42a0-ab88-20f7382dd24c"

New-AzDeployment -Location $Location -TemplateFile "$env:BUILD_SOURCESDIRECTORY\Templates\Policy\rbac-assignment-lighthouse.json" -policyAssignmentName $policyAssignmentName -rbacRoleId $roleDefId

Start-Sleep 15

# Create a remediation for a specific assignment
Start-AzPolicyRemediation -Name 'tem-monitoring-vm-remediation' -PolicyAssignmentId $assignment.PolicyAssignmentId -ResourceDiscoveryMode ReEvaluateCompliance



# Assign VM scale set monitoring policy initiative
$policySetDef = Get-AzPolicySetDefinition -Name "75714362-cae7-409e-9b99-a8e5075b7fad"
$subscriptionId = (Get-AzContext).Subscription.Id

$workspace = Get-AzResource -ResourceType Microsoft.OperationalInsights/workspaces -Name $LogAnalyticsWorkspaceName
$workspaceId = $workspace.ResourceId
$policyParams = @{
    "logAnalytics_1" = $workspaceId
}
$policyAssignmentName = 'TietoEVRYMSAzureMonitorVMSSsAssignment'
$assignment = New-AzPolicyAssignment -Name $policyAssignmentName -DisplayName 'TietoEVRY Managed Service Azure Monitor for VM Scale Sets Policy' -Scope "/subscriptions/$SubscriptionId" -PolicySetDefinition $policySetDef -Location $location -PolicyParameterObject $policyParams -AssignIdentity

Start-Sleep 20

# Use the $policyDef to get to the roleDefinitionIds array
#$roleDefinitionIds = $policyDef.Properties.policyRule.then.details.roleDefinitionIds
$roleDefId = "b24988ac-6180-42a0-ab88-20f7382dd24c"

New-AzDeployment -Location $Location -TemplateFile "$env:BUILD_SOURCESDIRECTORY\Templates\Policy\rbac-assignment-lighthouse.json" -policyAssignmentName $policyAssignmentName -rbacRoleId $roleDefId

Start-Sleep 15

# Create a remediation for a specific assignment
Start-AzPolicyRemediation -Name 'tem-monitoring-vmss-remediation' -PolicyAssignmentId $assignment.PolicyAssignmentId -ResourceDiscoveryMode ReEvaluateCompliance



# Assign Security Center custom log analytics configuration
$policyDef = Get-AzPolicyDefinition -Name "8e7da0a5-0a0e-4bbc-bfc0-7773c018b616"
$subscriptionId = (Get-AzContext).Subscription.Id

$workspace = Get-AzResource -ResourceType Microsoft.OperationalInsights/workspaces -Name $LogAnalyticsWorkspaceName
$workspaceId = $workspace.ResourceId
$policyParams = @{
    "logAnalytics" = $workspaceId
}

$policyAssignmentName = 'TietoEVRYMSEnableSCAutoProvAssignment'
$assignment = New-AzPolicyAssignment -Name $policyAssignmentName -DisplayName 'TietoEVRY Managed Service Enable Security Center''s auto provisioning of the Log Analytics agent' -Scope "/subscriptions/$SubscriptionId" -PolicyDefinition $policyDef -Location $location -PolicyParameterObject $policyParams -AssignIdentity

Start-Sleep 20

# Use the $policyDef to get to the roleDefinitionIds array
#$roleDefinitionIds = $policyDef.Properties.policyRule.then.details.roleDefinitionIds
$roleDefId = "b24988ac-6180-42a0-ab88-20f7382dd24c"

New-AzDeployment -Location $Location -TemplateFile "$env:BUILD_SOURCESDIRECTORY\Templates\Policy\rbac-assignment-lighthouse.json" -policyAssignmentName $policyAssignmentName -rbacRoleId $roleDefId

Start-Sleep 15

# Create a remediation for a specific assignment
Start-AzPolicyRemediation -Name 'tem-monitoring-enablesc-remediation' -PolicyAssignmentId $assignment.PolicyAssignmentId -ResourceDiscoveryMode ReEvaluateCompliance