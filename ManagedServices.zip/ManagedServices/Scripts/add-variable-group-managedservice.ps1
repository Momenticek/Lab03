#-------------------------------
# Copyright (c) TietoEVRY. All rights reserved.
# Create Azure DevOps project with matching Azure Subscription
#   and link those
#-------------------------------
param (
    [string]$orgName,
#    [string]$subscriptionName,
    [string]$projectName,
#    [string]$projectPrefix,
    [string]$repositoryName = 'ManagedServices'
)

function CreateCoreVariableGroup {
    param (
        [string]$newVariableGroupName
    )
    $variables = "Placeholder=PlaceholderValue"
    $variableGroup = az pipelines variable-group create --name $newVariableGroupName --variables $variables --organization $organizationUrl --project $projectName --authorize true | ConvertFrom-Json

    $varTable = @{
        "admin.azureConnection" = "TietoEVRY Azure DevOps Test"
        "admin.subscriptionId" = "e5f3913a-4b59-46d9-bd7d-8466273a0edd"
        "backup.resourceGroup" = "tem-backup-rg"
        "backup.retentionDays" = 90
        "backup.scheduleTime" = "['01:00:00Z']"
        "backup.scheduleTimeZone" = "UTC"
        "backup.storageType" = "GeoRedundant"
        "backup.vaultName" = "tem-backup-rsv"
        "monitoring.automationAccountName" = "tem-monitoring-automation"
        "monitoring.enabledSolutions" = "['all']"
        "monitoring.resourceGroup" = "tem-monitoring-rg"
        "monitoring.workspaceName" = "tem-monitoring-workspace"
        "settings.location" = "WestEurope"
    }

    $varTable

    foreach ($key in $varTable.Keys) {
        az pipelines variable-group variable create --name $key --value $varTable[$key] --organization $organizationUrl --project $projectName --group-id $variableGroup.id | Out-Null
    }

}

if([string]::IsNullOrWhiteSpace($orgName))
{
    $orgName = Read-Host 'Please enter name of your Azure DevOps organization (ex: TietoEVRY)'
}

#if([string]::IsNullOrWhiteSpace($subscriptionName))
#{
#    $orgName = Read-Host 'Please enter name of your Azure Subscription (ex: TietoEVRY)'
#}

if([string]::IsNullOrWhiteSpace($projectName))
{
    $projectName = Read-Host 'Please enter name of Azure DevOps project'
}

# Global parameters
Write-Output "Setting parameters"
#$location = "WestEurope"
$fontColor = (Get-Host).UI.RawUI.ForegroundColor

# Get Azure Subscription
#Write-Output "Getting Azure Subscription"
#$subscription = az account list --query "[?name=='$subscriptionName']" | ConvertFrom-Json
#if ($null -eq $subscription)
#{
#    Write-Error "Subscription not found."
#    Exit 1
#}
#
#az account set --subscription $subscription.id

# Get or create Project
#Write-Output "Verifying Azure DevOps Project"
$organizationUrl = "https://dev.azure.com/$orgName/"
#$projects = az devops project list --organization $organizationUrl --query "[value]" | ConvertFrom-Json
# foreach ($testProj in $projects)
#{
#    if ($testProj.name -eq $projectName)
#    {
#        $project = $testProj
#    }
#}
#if ($null -eq $project)
#{
#    $project = az devops project create --name $projectName --organization $organizationUrl --description 'Automatically created.' | ConvertFrom-Json
#}

# Create Service Connection if needed
Write-Output "Verifying Azure Service Connection"
#$endpoints = az devops service-endpoint list --project $projectName --organization $organizationUrl | ConvertFrom-Json
#$endPointFound = $false;

#foreach ($endpoint in $endpoints)
#{
#    if ($endpoint.data.subscriptionId -eq $subscription.id)
#    {
#        $endPointFound = $true;
#    }
#}

#$devopsSpName = 'devops' + $projectName
#if (-not $endPointFound)
#{
#    Write-Output "Creating Azure Service Principal"
#    $devOpsSp = az ad sp create-for-rbac --name $devopsSpName | ConvertFrom-Json
#    $Env:AZURE_DEVOPS_EXT_AZURE_RM_SERVICE_PRINCIPAL_KEY=$devOpsSp.password
#    az devops service-endpoint azurerm create --azure-rm-service-principal-id $devopsSp.appId --azure-rm-subscription-id $subscription.id --azure-rm-subscription-name $subscription.name --azure-rm-tenant-id $subscription.tenantId --name 'Azure Endpoint' --org $organizationUrl --project $projectName | Out-Null
#}

# Create Repository
Write-Output "Verifying Azure DevOps Repository"
#$repos = az repos list --organization $organizationUrl --project $projectName --query "[?name=='$repositoryName']" | ConvertFrom-Json
#if ($null -eq $repos)
#{
#    az repos create --name $repositoryName --organization $organizationUrl --project $projectName | Out-Null
#}

# Create KeyVault to store secret values
# Write-Output "Verifying Azure Keyvault for Secret Variables"
# $rgDevOps = $projectName + "DevOps"
# $rgExists = az group exists --name $rgDevOps
#if ($rgExists -eq $false)
#{
#    az group create --location $location --name $rgDevOps | Out-Null
#}
#
#$keyvaults = az keyvault list --resource-group $rgDevOps | ConvertFrom-Json
#if ($null -eq $keyvaults)
#{
#    Write-Output "Creating Test Keyvault and setting RBAC permissions"
#    [string]$id = New-Guid
#    $kvName = $projectPrefix + "t" + $id.Substring(0, $id.IndexOf('-'))
#    az keyvault create --name $kvName --location $location --resource-group $rgDevOps --enabled-for-template-deployment true --sku standard | Out-Null
#    #$spnName = "http://" + $devopsSpName
#    #az keyvault set-policy --name $kvName --resource-group $rgDevOps --spn $spnName --secret-permissions get list | Out-Null
#    az keyvault secret set --name SecretPlaceholder --vault-name $kvName --value SecretPlaceholderValue | Out-Null
#
#    Write-Output "Creating Production Keyvault and setting RBAC permissions"
#    [string]$id = New-Guid
#    $kvName = $projectPrefix + "p" + $id.Substring(0, $id.IndexOf('-'))
#    az keyvault create --name $kvName --location $location --resource-group $rgDevOps --enabled-for-template-deployment true --sku standard | Out-Null
    #$spnName = "http://" + $devopsSpName
    #az keyvault set-policy --name $kvName --resource-group $rgDevOps --spn $spnName --secret-permissions get list | Out-Null
#    az keyvault secret set --name SecretPlaceholder --vault-name $kvName --value SecretPlaceholderValue | Out-Null
#}

# Create Variable Groups
Write-Output "Verifying Azure DevOps Variable Groups"
#$variableGroups = az pipelines variable-group list --org $organizationUrl --project $projectName --group-name $repositoryName* | ConvertFrom-Json
#if ($null -eq $variableGroups)
#{
    $variables = "Placeholder=PlaceholderValue"

    $variableGroupName = "Test"+ $repositoryName
    CreateCoreVariableGroup $variableGroupName
    $variableGroupName = "Production"+ $repositoryName
    CreateCoreVariableGroup $variableGroupName

    $variableGroupName = "Test"+ $repositoryName + "Secret"
    az pipelines variable-group create --name $variableGroupName --variables $variables --organization $organizationUrl --project $projectName --authorize true | Out-Null
    $variableGroupName = "Production"+ $repositoryName + "Secret"
    az pipelines variable-group create --name $variableGroupName --variables $variables --organization $organizationUrl --project $projectName --authorize true | Out-Null

    Write-Output "Go to secret variable groups and connect those to Keyvault using Azure EndPoint Service Connection."
#}
(Get-Host).UI.RawUI.ForegroundColor = $fontColor